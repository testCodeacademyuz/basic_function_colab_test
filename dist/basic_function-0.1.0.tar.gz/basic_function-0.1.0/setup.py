from setuptools import setup

setup(
   name='basic_function',
   version='0.1.0',
   packages=['basic_function'],
   description='This is Basic Function Test',
   install_requires=[
       "requests",
   ]
) 